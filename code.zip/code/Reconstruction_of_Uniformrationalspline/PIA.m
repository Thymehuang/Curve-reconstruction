function [C,w] = PIA(R1,R2,R3,C,w,m,N,M,B_x,B_y,B_2x,B_2y,B_3x,B_3y)
%FUNC PIA

D=[R1;R2;R3];

c=norm(D'*D,'inf');
mu=2/c;

co_r3=0;

lamb=0.00425;%权重迭代的超参数

%构造b
epsilon1= 0.01;
epsilon2=-0.01;
b=[zeros(1,m),epsilon1*ones(1,m),epsilon2*ones(1,m)]';

iter=0.01;%迭代次数

E_sum=1e20;%能量
del=1e5;%迭代误差
Esp=1e-5;%相邻两次迭代误差之差
E_sum_last=0;%上一步迭代的总能量
E_ls_last=1e10;%上一步迭代的最小二乘误差

E_LS=[];%最小二乘误差
E_SUM=[];%总能量
E_MAX=[];%最大误差
E_AVE=[];%平均误差

    disp("---")
% while del>Esp
for iter=1:200

    del_w1=delta_w123(m,C,w,R1,B_x,B_y,0,N,M);
    del_w2=delta_w123(m,C,w,R2,B_2x,B_2y,epsilon1,N,M);
    del_w3=delta_w123(m,C,w,R3,B_3x,B_3y,epsilon2,N,M);

    disp("---")

    w=w+lamb*(del_w1+del_w2+del_w3);

    %%%%%%%%%更换新的w%%%%%%%%%%
    %数据点的有理B样条张量基矩阵的求解(R1)
    R1=zeros(m,M*N);
    for i=1:m
        for j=1:M*N
            [x_index,y_index]=func1(j,M,N,0);
            R1(i,j)=B_x(x_index,i)*B_y(y_index,i)*w(j);
        end
    end
    for i=1:m
        R1(i,:)=R1(i,:)/sum(R1(i,:));%得到有理B样条基
    end
    %正向扩充点的有理B样条张量基矩阵求解(R2)
    R2=zeros(m,M*N);
    for i=1:m
        for j=1:M*N
            [x_1index,y_1index]=func1(j,M,N,0);
            R2(i,j)=B_2x(x_1index,i)*B_2y(y_1index,i)*w(j);
        end
    end
    for i=1:m
        R2(i,:)=R2(i,:)/sum(R2(i,:));%得到正向扩充点的有理B样条基
    end
    %反向扩充点的混合基矩阵求解(R3)
    R3=zeros(m,M*N);
    for i=1:m
        for j=1:M*N
            [x_1index,y_1index]=func1(j,M,N,0);
            R3(i,j)=B_3x(x_1index,i)*B_3y(y_1index,i)*w(j);
        end
    end
    for i=1:m
        R3(i,:)=R3(i,:)/sum(R3(i,:));%得到反向扩充点的有理B样条基
    end
    D=[R1;R2;R3];

    %超参数的设定，为控制变量，设置同样的mu
    % c=max(sum(D'*D,2));
    c=norm(D'*D,'inf');
    mu=2/c;
    
    %C的迭代%第k+1步的C
    Delta=D'*(b-D*C); 
    C=C+mu*Delta;
    
    %正则项3
    [regular3,~]=R_3(C,N,M);

    E_sum=norm(R1*C,2)^2+norm(R2*C,2)^2+norm(R3*C,2)^2+co_r3*regular3; 
    E_ls=norm(R1*C,2)^2;%最小二乘误差
    E_ave=E_ls/m;%平均误差
    E_max=max(abs(R1*C));

    if iter>1
        del=abs(E_sum-E_sum_last);%迭代误差
        E_sum_last=E_sum;%将这一步的能量储存
    end
    E_SUM=[E_SUM,E_sum];
    E_LS=[E_LS,E_ls];
    E_MAX=[E_MAX,E_max];
    E_AVE=[E_AVE,E_ave];

    disp('----------------------')
    disp(['第',num2str(iter),'次循环']);
    disp(['迭代误差：',num2str(del)])
    disp(['能量：',num2str(E_sum)])
    disp(['最小二乘误差：',num2str(E_ls)])
    disp(['相对最大误差',num2str(E_max)])
    disp(['平均误差：',num2str(E_ave)])
    
end


end


