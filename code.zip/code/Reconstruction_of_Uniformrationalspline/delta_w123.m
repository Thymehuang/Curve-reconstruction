function Del_w1 = delta_w123(m,C,w,R,B_x,B_y,epsilon,N,M)
%DELTA_W1 权重w的迭代变化量一,二,三
%   此处显示详细说明

Del_w1=zeros(N*M,1);%初始化权重迭代向量
f=R*C;
for kl=1:N*M
    v1=0;%初始定0，用来求和
    for p=1:m
        [K,L]=func1(kl,M,N,0);
        
        v1=v1+2*(f(p,1)-epsilon)*(C(kl)*B_x(K,p)*B_y(L,p)*Sum_w_x_y(w,B_x(:,p),B_y(:,p),M,N)/Sum_w_x_y(w,B_x(:,p),B_y(:,p),M,N)-B_x(K,p)*B_y(L,p)*Sum_w_x_y([C,w],B_x(:,p),B_y(:,p),M,N)/(Sum_w_x_y(w,B_x(:,p),B_y(:,p),M,N))^2);
    end
    Del_w1(kl,1)=v1;
end

end

