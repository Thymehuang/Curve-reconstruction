function [C,w] = PIA_NURBS(R1,R2,R3,A,C,w,m,N,M,B_x,B_y,B_2x,B_2y,B_3x,B_3y,dB_x,dB_y,v_i)
%FUNC 基于NURBS普通PIA
%   此处显示详细说明

D=[R1;R2;R3;A];

%超参数的设定，为控制变量，设置同样的mu
% c=max(sum(D'*D,2));
c=norm(D'*D,'inf');
mu=2/c;

%正则项的系数
% co_r1=0;%猜测与曲线曲率有关，曲率越大的地方效果越好%约在0.001~0.005起作用%0.001
% co_r2=0;%与L1正则项相同，%约在<0.005起作用%0.004
co_r3=0;

lamb=20;%权重迭代的超参数

%构造b
epsilon1= 0.01;
epsilon2=-0.01;
b=[zeros(1,m),epsilon1*ones(1,m),epsilon2*ones(1,m),zeros(1,m)]';

iter=10;%迭代次数

E_sum=1e20;%能量
del=1e5;%迭代误差
Esp=1e-5;%相邻两次迭代误差之差
E_sum_last=0;%上一步迭代的总能量
E_ls_last=1e10;%上一步迭代的最小二乘误差

E_SUM=[];
E_LS=[];



% while del>Esp
for iter=1:100

    lamb=5+1/iter^3;


    %正则项3
    [regular3,~]=R_3(C,N,M);

    del_w1=delta_w123(m,C,w,R1,B_x,B_y,0,N,M);
    del_w2=delta_w123(m,C,w,R2,B_2x,B_2y,epsilon1,N,M);
    del_w3=delta_w123(m,C,w,R3,B_3x,B_3y,epsilon2,N,M);
    del_w4=delta_w4(m,C,w,A,B_x,B_y,dB_x,dB_y,v_i,N,M);


    % while 1
        %w的迭代
        w=w-lamb*(del_w1+del_w2+del_w3+del_w4);

        %%%%%%%%%更换新的w%%%%%%%%%%
        %数据点的有理B样条张量基矩阵的求解(R1)
        R1=zeros(m,M*N);
        for i=1:m
            for j=1:M*N
                [x_index,y_index]=func1(j,M,N,0);
                R1(i,j)=B_x(x_index,i)*B_y(y_index,i)*w(j);
            end
        end
        bw=zeros(m,1);%约束四中需要的变量
        for i=1:m
            R1(i,:)=R1(i,:)/sum(R1(i,:));%得到有理B样条基
            bw(i,1)=sum(R1(i,:));
        end
        %正向扩充点的有理B样条张量基矩阵求解(R2)
        R2=zeros(m,M*N);
        for i=1:m
            for j=1:M*N
                [x_1index,y_1index]=func1(j,M,N,0);
                R2(i,j)=B_2x(x_1index,i)*B_2y(y_1index,i)*w(j);
            end
        end
        for i=1:m
            R2(i,:)=R2(i,:)/sum(R2(i,:));%得到正向扩充点的有理B样条基
        end
        %反向扩充点的混合基矩阵求解(R3)
        R3=zeros(m,M*N);
        for i=1:m
            for j=1:M*N
                [x_1index,y_1index]=func1(j,M,N,0);
                R3(i,j)=B_3x(x_1index,i)*B_3y(y_1index,i)*w(j);
            end
        end
        for i=1:m
            R3(i,:)=R3(i,:)/sum(R3(i,:));%得到反向扩充点的有理B样条基
        end
        %构造所需的dx_bw,dy_bw
        dx_bw=zeros(m,1);
        for i=1:m
            v1=0;
            for j=1:N*M
                [I,J]=func1(j,M,N,0);
                v1=v1+w(j)*dB_x(I,i)*B_y(J,i);
            end
            dx_bw(i,1)=v1;
        end
        dy_bw=zeros(m,1);
        for i=1:m
            v2=0;
            for j=1:N*M
                [I,J]=func1(j,M,N,0); 
                v2=v2+w(j)*B_x(I,i)*dB_y(J,i);
            end
            dy_bw(i,1)=v2;
        end
        %约束四中的A         (A)
        A=zeros(m,N*M);
        for i=1:m %变量xi,yi
            for j=1:N*M %Cij中i*j
                [I,J]=func1(j,M,N,0);
                A(i,j)=((w(j)*dB_x(I,i)*B_y(J,i)*bw(i,1)-w(j)*B_x(I,i)*B_y(J,i)*dx_bw(i,1))*v_i(i,1)...
                    +(w(j)*B_x(I,i)*dB_y(J,i)*bw(i,1)-w(j)*B_x(I,i)*B_y(J,i)*dy_bw(i,1))*v_i(i,2))/(bw(i,1))^2;
            end
        end

        D=[R1;R2;R3;A];
        
        %超参数的设定，为控制变量，设置同样的mu
        % c=max(sum(D'*D,2));
        c=norm(D'*D,'inf');
        mu=2/c;
        
        %C的迭代%第k+1步的C
        Delta=D'*(b-D*C); 
        C=C+mu*Delta;
        
        E_sum=norm(R1*C,2)^2+norm(R2*C,2)^2+norm(R3*C,2)^2+norm(A*C,2)^2+co_r3*regular3; 
        E_ls=norm(R1*C,2)^2;
        
        

        % disp(['最小二乘误差：',num2str(E_ls)])
        % if E_ls>E_ls_last        
        %         lamb=10/count;
        %         count=count+1;
        % else
            lamb=10/iter;
            E_ls_last=E_ls;
            if iter>1
                del=abs(E_sum-E_sum_last);%迭代误差
                E_sum_last=E_sum;%将这一步的能量储存
            end
            E_SUM=[E_SUM,E_sum];
            E_LS=[E_LS,E_ls];
            % break;%当能量在减小时跳出循环继续迭代
        % end
    % end

   

    % if mod(iter,100)==0
    disp('----------------------')
    disp(['第',num2str(iter),'次循环']);
    disp(['能量：',num2str(E_sum)])
    disp(['迭代误差：',num2str(del)])
    disp(['最小二乘误差：',num2str(E_ls)])
    % end
    
    % %显示曲线变化
    % if mod(iter,10)==0
    %     disp(['第',num2str(iter),'次循环']);
    %     result_show_NURBS(P_i,m,M,N,d_l,C,w);
    % end

    % iter=iter+1;
end

% iter=iter-1;
% disp('----------------------')
% disp(['第',num2str(iter),'次循环']);
% disp(['能量项：',num2str(E)])
% disp(['迭代误差：',num2str(del)])
% disp(['mu:',num2str(mu)])

%双曲线图（总能量和最小二乘误差
px=linspace(1,length(E_LS),length(E_LS));
figure;
yyaxis left
plot(px,E_SUM,'-r')
ylabel('能量')
yyaxis right
plot(px,E_LS,'-b')
legend('总能量','最小二乘误差')
axis auto
writematrix(E_SUM,'ESUM_NURBS.xls')
writematrix(E_LS,'ELS_NURBS.xls')
end
