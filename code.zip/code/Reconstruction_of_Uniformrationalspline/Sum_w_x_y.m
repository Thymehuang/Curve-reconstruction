function Sxy1 = Sum_w_x_y(W,Bx,By,M,N)
%SUM_W_X_Y 求关于系数，样条函数基的求和
%   此处显示详细说明
%W:     权系数的矩阵，其中可能包含两个权,eg:[C,w]
%Bx,By: 基函数，也可能是导数,eg:B_x,dB_x

[NM,n]=size(W);%NM代表权的个数，n代表权的种类
if n==2
    b=zeros(NM,1);
    for i=1:NM
        b(i)=W(i,1)*W(i,2);
    end
    W=b;%完成赋值，此时W(i)=C(i)*w(i)
end

Sxy1=0;
for j=1:NM
    [I,J]=func1(j,M,N,0);
    Sxy1=Sxy1+W(j)*Bx(I)*By(J);
end

    

end

