function Del_w4 = delta_w4(m,C,w,A,B_x,B_y,dB_x,dB_y,v_i,N,M)
%DELTA_W4 权重w的迭代变化量四
%   此处显示详细说明

Del_w4=zeros(N*M,1);%初始化权重4向量
gra_f=A*C;
for kl=1:N*M
    v1=0;%初始定0，用来求和
    for p=1:m
        [K,L]=func1(kl,M,N,0);
        v1=v1+2*gra_f(p,1)*(((C(kl)*dB_x(K,p)*B_y(L,p)*Sum_w_x_y(w,B_x(:,p),B_y(:,p),M,N)+Sum_w_x_y([C,w],dB_x(:,p),B_y(:,p),M,N)*B_x(K,p)*B_y(L,p)-C(kl)*B_x(K,p)*B_y(L,p)*Sum_w_x_y(w,dB_x(:,p),B_y(:,p),M,N)-Sum_w_x_y([C,w],B_x(:,p),B_y(:,p),M,N)*dB_x(K,p)*B_y(L,p))*Sum_w_x_y(w,B_x(:,p),B_y(:,p),M,N)^2 ...
            -(Sum_w_x_y([C,w],dB_x(:,p),B_y(:,p),M,N)*Sum_w_x_y(w,B_x(:,p),B_y(:,p),M,N)-Sum_w_x_y([C,w],B_x(:,p),B_y(:,p),M,N)*Sum_w_x_y(w,dB_x(:,p),B_y(:,p),M,N))*2*Sum_w_x_y(w,B_x(:,p),B_y(:,p),M,N)*B_x(K,p)*B_y(L,p))*v_i(p,1)...
                           +((C(kl)*B_x(K,p)*dB_y(L,p)*Sum_w_x_y(w,B_x(:,p),B_y(:,p),M,N)+Sum_w_x_y([C,w],B_x(:,p),dB_y(:,p),M,N)*B_x(K,p)*B_y(L,p)-C(kl)*B_x(K,p)*B_y(L,p)*Sum_w_x_y(w,B_x(:,p),dB_y(:,p),M,N)-Sum_w_x_y([C,w],B_x(:,p),B_y(:,p),M,N)*B_x(K,p)*dB_y(L,p))*Sum_w_x_y(w,B_x(:,p),B_y(:,p),M,N)^2 ...
            -(Sum_w_x_y([C,w],B_x(:,p),dB_y(:,p),M,N)*Sum_w_x_y(w,B_x(:,p),B_y(:,p),M,N)-Sum_w_x_y([C,w],B_x(:,p),B_y(:,p),M,N)*Sum_w_x_y(w,B_x(:,p),dB_y(:,p),M,N))*2*Sum_w_x_y(w,B_x(:,p),B_y(:,p),M,N)*B_x(K,p)*B_y(L,p))*v_i(p,2))/(Sum_w_x_y(w,B_x(:,p),B_y(:,p),M,N)^4);
    end
    Del_w4(kl,1)=v1;
end
end

