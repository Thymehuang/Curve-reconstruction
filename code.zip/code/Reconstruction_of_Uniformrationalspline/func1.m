function [x,y] = func1(j,M,N,count)
%FUNC j in [1,N*M] ->(i,j)
%   此处显示详细说明
%count:     默认为0
%j:         混合基矩阵中的列索引
%M,N:       ...
%x,y:       返回混合基矩阵中的B_x,B_y索引
if j<=M
    y=j;
    x=1+count;
else
    j=j-M;
    count=count+1;
    [x,y]=func1(j,M,N,count);
end
end

