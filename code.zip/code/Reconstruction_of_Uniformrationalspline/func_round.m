function y = func_round(C,i,j,N,M)
%FUNC2 辅助计算正则项3——计算右方在C(i,j)的产生的梯度
%   此处显示详细说明
% y=2*(C(i,j)+C(i,j+2)+C(i-1,j+1)+C(i+1,j+1)-4*C(i,j+1));

if i<1 || i>N || j<1 || j>M %首先i,j要有意义
    y=0;
else

    if i-1<=0
        gra_N=0;
        gra_S=C(i+1,j)-C(i,j);
    elseif i+1>=N
        gra_N=C(i-1,j)-C(i,j);
        gra_S=0;
    else
        gra_N=C(i-1,j)-C(i,j);
        gra_S=C(i+1,j)-C(i,j);
    end
    
    if j-1<=0
        gra_W=0;
        gra_E=C(i,j+1)-C(i,j);
    elseif j+1>=M
        gra_W=C(i,j-1)-C(i,j);
        gra_E=0;
    else
        gra_W=C(i,j-1)-C(i,j);
        gra_E=C(i,j+1)-C(i,j);
    end
    y=2*(gra_E+gra_W+gra_S+gra_N);
end
end

