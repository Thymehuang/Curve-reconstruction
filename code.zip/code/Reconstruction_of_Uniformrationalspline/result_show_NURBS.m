function [] = result_show_NURBS(P_i,m,M,N,d_l,C,w)
%UNTITLED 结果展示
%   此处显示详细说明result_show

%参数定义
    %x,y轴上的节点向量
    x_1 = min(P_i(:,1));
    x_2 = max(P_i(:,1));
    
    y_1 = min(P_i(:,2));
    y_2 = max(P_i(:,2));
    
    %x，y方向的节点向量
    Knot_x=linspace(x_1-d_l,x_2+d_l,N-2);
    Knot_x=[x_1-d_l,x_1-d_l,x_1-d_l,Knot_x,x_2+d_l,x_2+d_l,x_2+d_l];
    Knot_y=linspace(y_1-d_l,y_2+d_l,M-2);
    Knot_y=[y_1-d_l,y_1-d_l,y_1-d_l,Knot_y,y_2+d_l,y_2+d_l,y_2+d_l];




%隐式曲线表达的曲面
%数据点集P

px=linspace(x_1-1,x_2+1,500);
py=linspace(y_1-1,y_2+1,500);

P=zeros(length(px)*length(py),2);
for i=1:length(px)*length(py)
    [x_3index,y_3index]=func1(i,length(py),length(px),0);
    P(i,1)=px(x_3index);
    P(i,2)=py(y_3index);
end
[row,~]=size(P);
Bx=zeros(N,row);
for j=1:N
    Bx(j,:)=C_Bspline(Knot_x(j),Knot_x(j+1),Knot_x(j+2),Knot_x(j+3),Knot_x(j+4),P(:,1));
end


By=zeros(M,row);
for j=1:M
    By(j,:)=C_Bspline(Knot_y(j),Knot_y(j+1),Knot_y(j+2),Knot_y(j+3),Knot_y(j+4),P(:,2));
end


%数据点的混合基矩阵的求解
Rxy=zeros(row,M*N);
for i=1:row
    for j=1:M*N
        [x_index,y_index]=func1(j,M,N,0);
        Rxy(i,j)=Bx(x_index,i)*By(y_index,i)*w(j);
    end
end
for i=1:m
    Rxy(i,:)=Rxy(i,:)/sum(Rxy(i,:));
end
z=Rxy*C;
pz=reshape_pz(px,py,z);
figure;
[pX,pY]=meshgrid(px,py);
levels = [0 0];
plot(P_i(:,1),P_i(:,2),'black.')
hold on
contour(pX, pY, pz,levels,'red-','LineWidth',1);
hold on 
set(gcf, 'Units', 'inches', 'Position', [0, 0, 6, 4]); % 将宽度设置为6英寸、高度设置为4英寸
axis equal
axis off


end

