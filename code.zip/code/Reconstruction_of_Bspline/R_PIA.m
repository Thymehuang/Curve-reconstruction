function C = R_PIA(B,B1,m,C,N,M,B2)
%PIA 加正则项的PIA
%   此处显示详细说明

% D=[B;B1;A_v;B2];
D=[B;B1;B2];

%超参数的设定，为控制变量，设置同样的mu
c=max(sum(D'*D,2));
mu=2/c;

epsilon1=0.01*ones(1,m);     
epsilon2=-0.01*ones(1,m);
b=[zeros(1,m),epsilon1,epsilon2]';
e1=mean(epsilon1);
disp(['偏移误差:',num2str(e1)])

%正则项的系数
co_r3=0.134;
disp(['正则项系数：',num2str(co_r3)])

iter=1;%迭代次数

E_ls=0;%最小二乘误差
E=0;%总能量
E_LS=[];
E_SUM=[];
del=1e5;%迭代误差
Esp=1e-8;%相邻两次迭代误差之差
delta_last=0;

tic;
while del > Esp
    Delta1=B*C;
   
    %正则项3
    [regular3,C3_gradient]=R_3(C,N,M);


    Delta=D'*(b-D*C);
    C=C+mu*Delta-co_r3*C3_gradient;

    E=norm(B*C,2)^2+norm(B1*C,2)^2+norm(B2*C,2)^2+co_r3*regular3; 
    E_ls=norm(B*C,2)^2;%最小二乘误差
    E_ave=E_ls/m;%平均误差
    E_max=max(abs(B*C));


    if iter>1
    delta_now=E+co_r3*regular3;
    del=abs(delta_now-delta_last);%迭代误差
    delta_last=delta_now;
    end

    if mod(iter,10000)==0
        break;
    end

    E_SUM=[E_SUM,E];
    E_LS=[E_LS,E_ls];

    iter=iter+1;
end
elapsedTime = toc;

disp(['第',num2str(iter),'次循环']);
disp(['迭代误差：',num2str(del)])
disp(['总能量',num2str(E)])
disp(['最小二乘误差：',num2str(E_ls)])
disp(['相对最大误差',num2str(E_max)])
disp(['平均误差：',num2str(E_ave)])
disp(['正则项3：',num2str(regular3)]);
disp('------------------------')
disp(['R_PIA迭代执行时间：', num2str(elapsedTime), ' 秒']);

end

