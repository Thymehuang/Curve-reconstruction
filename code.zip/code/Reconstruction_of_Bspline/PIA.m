function C = PIA(B,B1,m,C,N,M,B2)
%PIA I-PIA
%   此处显示详细说明

D=[B;B1;B2];

%超参数的设定，为控制变量，设置同样的mu
c=norm(D'*D,'inf');
mu=2/c;


epsilon=0.01*ones(1,m);     
epsilon2=-0.01*ones(1,m);
b=[zeros(1,m),epsilon,epsilon2]';
iter=1;%迭代次数

co_r3=0.134;

E_ls=0;%最小二乘误差
E=0;%总能量
E_LS=[];%最小二乘误差
E_SUM=[];%总能量
E_MAX=[];%最大误差
E_AVE=[];%平均误差
del=1e5;%迭代误差
Esp=1e-7;%相邻两次迭代误差之差
delta_last=0;

tic;
while del > Esp
    %正则项3
    [regular3,~]=R_3(C,N,M);

    Delta=D'*(b-D*C);
    C=C+mu*Delta;

    E=norm(B*C,2)^2+norm(B1*C,2)^2+norm(B2*C,2)^2+co_r3*regular3; 
    E_ls=norm(B*C,2)^2;%最小二乘误差
    E_ave=E_ls/m;%平均误差
    E_max=max(abs(B*C));

    if iter>1
    delta_now=E;
    del=abs(delta_now-delta_last);%迭代误差
    delta_last=delta_now;
    end

    E_SUM=[E_SUM,E];
    E_LS=[E_LS,E_ls];
    E_MAX=[E_MAX,E_max];
    E_AVE=[E_AVE,E_ave];
    
    if mod(iter,10000)==0
        disp("-----");
        break
    end

    iter=iter+1;
end
elapsedTime = toc;

disp(['第',num2str(iter),'次循环']);
disp(['迭代误差：',num2str(del)])
disp(['总能量',num2str(E)])
disp(['最小二乘误差：',num2str(E_ls)])
disp(['相对最大误差',num2str(E_max)])
disp(['平均误差：',num2str(E_ave)])
%正则项3
disp(['正则项3：',num2str(regular3)]);
disp(['PIA迭代执行时间：', num2str(elapsedTime), ' 秒']);


end

