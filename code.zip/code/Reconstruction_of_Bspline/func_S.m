function y = func_S(C,i,j,N,M)
%FUNC_S 辅助计算正则项3——计算下方在C(i,j)产生的梯度
%   此处显示详细说明


    if j-1<1%下一行不存在
        y=0;
    else
        y=2*(C(i,j)-C(i,j-1));
    end
    
   
    

end

