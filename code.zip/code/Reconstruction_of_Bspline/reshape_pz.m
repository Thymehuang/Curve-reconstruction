function pz = reshape_pz(px,py,z)
%RESHAPE 将列向量z改造成适应网格的矩阵形式:length(px)*length(py)
%   此处显示详细说明

m=length(px);
n=length(py);
pz=zeros(n,m);
for i=1:n
    for j=1:m
        pz(i,j)=z((i-1)*m+j);
    end
end
pz=pz';
end

