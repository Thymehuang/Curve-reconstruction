function C = C_initial(N,M)
%C_ 生成初始的C控制系数
%   此处显示详细说明

C_temp=zeros(N,M);
for i=1:N
    for j=1:M
        if  i>=floor(N/4)+1&&i<=floor(3*N/4)&&j>=floor(M/4)+1&&j<=floor(3*M/4)
            C_temp(i,j)=-1;
        else
             C_temp(i,j)=0;
        end
    end
end

C=zeros(N*M,1);
for i=1:N*M
    [x,y]=func1(i,M,N,0);
    C(i)=C_temp(y,x);
end
end

