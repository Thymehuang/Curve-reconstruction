function [P_i,n_i,v_i,m] = PointCloudData()
%PointCloudData 生成2D点云数据
%   此处显示详细说明
%数据点获取
%初始化
rng(123);%生成伪随机数

% %Example 1
m=400; %采样到的数据点个数
P_i = zeros(m,2);   %无序2D平面点云
n_i = zeros(m,2);   %对应单位法向量
v_i = zeros(m,2);   %法向量对应单位切向量
tt=linspace(0,2*pi,m);
y=sin(tt).*(3-5*sin(tt));
x=4*cos(tt);
Dy=cos(tt).*(10*sin(tt)-3);
Dx=2*sin(tt);
P_i=[x' y'];
for i=1:m
    v_i(i,1)=Dx(i)/sqrt(Dx(i)^2+Dy(i)^2);
    v_i(i,2)=Dy(i)/sqrt(Dx(i)^2+Dy(i)^2);
    n_i(i,1)=-v_i(i,2);
    n_i(i,2)=v_i(i,1);
end
% % 添加噪声
% for i =1:m
%     P_i(i,:) = P_i(i,:) + n_i(i,:)*(2*rand()-1)/10;
% end

% % Example 2
% Data=readmatrix("..\Datapoint\data3.xls");
% [m,~]=size(Data);
% P_i=Data(:,1:2);
% [n_i,v_i]=getnorm(P_i);

% % Example 3
% Data=readmatrix("..\Datapoint\data14.xls");
% [m,~]=size(Data);
% P_i=Data(:,1:2);
% [n_i,v_i]=getnorm(P_i);

% % Example 4
% Data=readmatrix("..\Datapoint\data.xls");
% [m,~]=size(Data);
% P_i=Data(:,1:2);
% [n_i,v_i]=getnorm(P_i);

% % Example 5
% Data=readmatrix("..\Datapoint\data10.xls");
% [m,~]=size(Data);
% P_i=Data(:,1:2);
% [n_i,v_i]=getnorm(P_i);

% % Example 6
% m=800;
% t=linspace(0,2*pi,m);
% x=(17/31*sin(235/57-32*t)+19/17* sin(192/55 - 30* t) + 47/32 *sin(69/25 - 29 *t) + 35/26* sin(75/34 - 27* t) + 6/31 *sin(23/10 - 26* t) + 35/43 *sin(10/33 - 25* t) + 126/43 *sin(421/158 - 24* t) + 143/57* sin(35/22 - 22 *t) + 106/27* sin(84/29 - 21 *t) + 88/25 *sin(23/27 - 20* t) + 74/27 *sin(53/22 - 19 *t) + 44/53* sin(117/25 - 18 *t) + 126/25 *sin(88/49 - 17* t) + 79/11 *sin(43/26 - 16* t) + 43/12 *sin(41/17 - 15* t) + 47/27 *sin(244/81 - 14 *t) + 8/5 *sin(79/19 - 13* t) + 373/46* sin(109/38 - 12* t) + 1200/31* sin(133/74 - 11* t) + 67/24 *sin(157/61 - 10 *t) + 583/28 *sin(13/8 - 8 *t) + 772/35 *sin(59/16 - 7 *t) + 3705/46* sin(117/50 - 6* t) + 862/13 *sin(19/8 - 5* t) + 6555/34 *sin(157/78 - 3* t) + 6949/13 *sin(83/27 - t) - 6805/54 *sin(2* t + 1/145) - 5207/37* sin(4* t + 49/74) - 1811/58 *sin(9* t + 55/43) - 63/20* sin(23* t + 2/23) - 266/177 *sin(28 *t + 13/18) - 2/21* sin(31* t + 7/16))/10;
% y=(70/37*sin(65/32-32*t)+11/12 *sin(98/41 - 31 *t) + 26/29 *sin(35/12 - 30* t) + 54/41 *sin(18/7 - 29 *t) + 177/71 *sin(51/19 - 27 *t) + 59/34 *sin(125/33 - 26 *t) + 49/29 *sin(18/11 - 25 *t) + 151/75 *sin(59/22 - 24* t) + 52/9 *sin(118/45 - 22* t) + 52/33* sin(133/52 - 21* t) + 37/45* sin(61/14 - 20* t) + 143/46 *sin(144/41 - 19 *t) + 254/47* sin(19/52 - 18 *t) + 246/35* sin(92/25 - 17* t) + 722/111* sin(176/67 - 16* t) + 136/23 *sin(3/19 - 15 *t) + 273/25 *sin(32/21 - 13* t) + 229/33 *sin(117/28 - 12* t) + 19/4* sin(43/11 - 11* t) + 135/8* sin(23/10 - 10 *t) + 205/6 *sin(33/23 - 8* t) + 679/45* sin(55/12 - 7* t) + 101/8* sin(11/12 - 6 *t) + 2760/59* sin(40/11 - 5 *t) + 1207/18* sin(21/23 - 4* t) + 8566/27* sin(39/28 - 3 *t) + 12334/29* sin(47/37 - 2 *t) + 15410/39 *sin(185/41 - t) - 596/17 *sin(9 *t + 3/26) - 247/28 *sin(14 *t + 25/21) - 458/131 *sin(23* t + 21/37) - 41/36* sin(28* t + 7/8))/10;
% P_i=[x' y'];
% [n_i,v_i]=getnorm(P_i);
% % % 添加噪声
% % for i =1:m
% %     P_i(i,:) = P_i(i,:) + n_i(i,:)*(2*rand()-1);
% % end

% % Example 7
% Data=readmatrix("..\Datapoint\data12.xls");
% [m,~]=size(Data);
% P_i=Data(:,1:2);
% [n_i,v_i]=getnorm(P_i);

% % Example 10
% m=500; %采样到的数据点个数
% P_i = zeros(m,2);   %无序2D平面点云
% n_i = zeros(m,2);   %对应单位法向量
% v_i = zeros(m,2);   %法向量对应单位切向量
% tt=linspace(0,2*pi,m);
% y=5*sin(tt);
% x=4*cos(tt);
% Dy=-5*cos(tt);
% Dx=4*sin(tt);
% P_i=[x' y'];
% for i=1:m
%     v_i(i,1)=Dx(i)/sqrt(Dx(i)^2+Dy(i)^2);
%     v_i(i,2)=Dy(i)/sqrt(Dx(i)^2+Dy(i)^2);
%     n_i(i,1)=-v_i(i,2);
%     n_i(i,2)=v_i(i,1);
% end
% % % 添加噪声
% % for i =1:m
% %     P_i(i,:) = P_i(i,:) + n_i(i,:)*(2*rand()-1)/10;
% % end

% 模拟2D点云
[P_i,n_i,v_i]=randomdata(P_i,n_i,v_i);

end

