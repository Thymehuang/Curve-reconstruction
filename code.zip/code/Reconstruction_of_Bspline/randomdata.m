function [P_i_tem,n_i_tem,v_i_tem] = randomdata(P_i,n_i,v_i)
%UNTITLED 将给定数据集打乱排列顺序
%   此处显示详细说明
% 生成乱序数组
rng(123);%生成伪随机数
len=length(P_i);
randomindex = randperm(len,len);
P_i_tem=zeros(len,2);
n_i_tem=zeros(len,2);
v_i_tem=zeros(len,2);

for i=1:len
    P_i_tem(i,1)=P_i(randomindex(i),1);
    P_i_tem(i,2)=P_i(randomindex(i),2);
    n_i_tem(i,1)=n_i(randomindex(i),1);
    n_i_tem(i,2)=n_i(randomindex(i),2);
    v_i_tem(i,1)=v_i(randomindex(i),1);
    v_i_tem(i,2)=v_i(randomindex(i),2);
end

end

