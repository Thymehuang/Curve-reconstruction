function [R3,C3_gradient]=R_3(C,N,M)
%R_3 计算第三正则项，及其对C的偏导


R3=0;%正则项能量，这一正则项的值

C1=reshape_pz(ones(M),ones(N),C); %格式为length(px)*length(py)
C1=C1';%需要转置一下
C_tmp=zeros(N,M);%作用在C上的梯度向量,先用矩阵储存
for i=1:N
    for j=1:M
        if i-1<=0
            gra_W=0;
            gra_E=C1(i+1,j)-C1(i,j);
        elseif i+1>=N
            gra_W=C1(i-1,j)-C1(i,j);
            gra_E=0;
        else
            gra_W=C1(i-1,j)-C1(i,j);
            gra_E=C1(i+1,j)-C1(i,j);
        end
        
        if j-1<=0
            gra_N=C1(i,j+1)-C1(i,j);
            gra_S=0;
        elseif j+1>=M
            gra_N=0;
            gra_S=C1(i,j-1)-C1(i,j);
        else   
            gra_N=C1(i,j+1)-C1(i,j);
            gra_S=C1(i,j-1)-C1(i,j);
        end

        R3=R3+(gra_E^2+gra_W^2+gra_N^2+gra_S^2);%累计算出正则项三
        
        C_tmp(i,j)=-2*(gra_E+gra_W+gra_N+gra_S)+func_N(C1,i,j,N,M)+...
            func_S(C1,i,j,N,M)+func_W(C1,i,j,N,M)+func_E(C1,i,j,N,M);
    end
end

R3=R3/16;
%将矩阵C_tmp改换成列矩阵
C3_gradient=zeros(N*M,1);
for i=1:N*M
    [xi,yi]=func1(i,M,N,0);
    C3_gradient(i)=C_tmp(xi,yi);
end
C3_gradient=C3_gradient/16;%
end







