function [] = result_show(P_i,m,M,N,d,C)
%UNTITLED 结果展示
%   此处显示详细说明result_show

%参数定义
    %x,y轴上的节点向量
    x_1 = min(P_i(:,1));
    x_2 = max(P_i(:,1));
    
    y_1 = min(P_i(:,2));
    y_2 = max(P_i(:,2));
    
    %x，y方向的节点向量
    Knot_x=linspace(x_1-d,x_2+d,N-2);
    Knot_x=[x_1-d,x_1-d,x_1-d,Knot_x,x_2+d,x_2+d,x_2+d];
    Knot_y=linspace(y_1-d,y_2+d,M-2);
    Knot_y=[y_1-d,y_1-d,y_1-d,Knot_y,y_2+d,y_2+d,y_2+d];




%隐式曲线表达的曲面
%数据点集P

px=linspace(x_1-1,x_2+1,500);
py=linspace(y_1-1,y_2+1,500);

P=zeros(length(px)*length(py),2);
for i=1:length(px)*length(py)
    [x_3index,y_3index]=func1(i,length(py),length(px),0);
    P(i,1)=px(x_3index);
    P(i,2)=py(y_3index);
end
[row,~]=size(P);
Bx=zeros(N,row);
for j=1:N
    Bx(j,:)=C_Bspline(Knot_x(j),Knot_x(j+1),Knot_x(j+2),Knot_x(j+3),Knot_x(j+4),P(:,1));
end


By=zeros(M,row);
for j=1:M
    By(j,:)=C_Bspline(Knot_y(j),Knot_y(j+1),Knot_y(j+2),Knot_y(j+3),Knot_y(j+4),P(:,2));
end


%数据点的混合基矩阵的求解
Bxy=zeros(row,M*N);
for i=1:row
    for j=1:M*N
        [x_index,y_index]=func1(j,M,N,0);
        Bxy(i,j)=Bx(x_index,i)*By(y_index,i);
    end
end

z=Bxy*C;
pz=reshape_pz(px,py,z);
%生成的曲线图
figure;
[pX,pY]=meshgrid(px,py);
levels = [0 0];
plot(P_i(:,1),P_i(:,2),'black.','LineWidth',1)
hold on
contour(pX, pY, pz,levels,'red-','LineWidth',1);
hold off
set(gcf, 'Units', 'inches', 'Position', [0, 0, 6, 4]); % 将宽度设置为6英寸、高度设置为4英寸
axis equal
axis off

% %生成小窗
% figure
% handaxes1=axes('Position',[0.1 0.1 0.8 0.8]);
% set(handaxes1,'Box','off')
% plot(P_i(:,1),P_i(:,2),'black.','LineWidth',1)
% hold on
% contour(pX, pY, pz,levels,'red-','LineWidth',1);
% hold on;
% axis([6,18,-1,1]);%设定图窗显示的位置
% set(handaxes1, 'XTickLabel', [], 'YTickLabel', []);
% box on
% 
% figure
% handaxes1=axes('Position',[0.1 0.1 0.8 0.8]);
% set(handaxes1,'Box','off')
% plot(P_i(:,1),P_i(:,2),'black.','LineWidth',1)
% hold on
% contour(pX, pY, pz,levels,'red-','LineWidth',1);
% hold on;
% axis([23,30,5,7]);%设定图窗显示的位置
% set(handaxes1, 'XTickLabel', [], 'YTickLabel', []);
% box on

%生成的曲面图
figure;
surf(pX,pY,pz,'EdgeColor','none')
colormap('jet')
xlabel('X');
ylabel('Y');
zlabel('Z');
axis equal

% 设置图像大小
fig = gcf; % 获取当前图像的句柄
fig.Units = 'centimeters'; % 设置单位为厘米
fig.Position(3) = 10; % 设置图像宽度为10厘米
fig.Position(4) = 8; % 设置图像高度为8厘米
%plot3(P(:,1),P(:,2),z,'.')



end

