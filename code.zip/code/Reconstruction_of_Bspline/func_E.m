function y = func_E(C,i,j,N,M)
%FUNC2 辅助计算正则项--计算右方在C(i,j)产生的梯度
%   此处显示详细说明
% y=2*(C(i,j)+C(i,j+2)+C(i-1,j+1)+C(i+1,j+1)-4*C(i,j+1));


   if i+1>N
       y=0;
   else
       y=2*(C(i,j)-C(i+1,j));
   end
    
  

end

