function [n_i,v_i] = getnorm(P_i)
%GETNORM 获取法向量
%   此处显示详细说明


[m,~]=size(P_i);
n_i=zeros(m,2);
v_i=zeros(m,2);
for i=1:m
    if i==m
        n_i(i,1)=-(P_i(i-1,2)-P_i(1,2));
        n_i(i,2)=(P_i(i-1,1)-P_i(1,1));
    elseif i==1
        n_i(i,1)=-(P_i(m,2)-P_i(2,2));
        n_i(i,2)=(P_i(m,1)-P_i(2,1));
    else
        n_i(i,1)=-(P_i(i-1,2)-P_i(i+1,2));
        n_i(i,2)=(P_i(i-1,1)-P_i(i+1,1));
    end
    d=sqrt(n_i(i,1)^2+n_i(i,2)^2);
    n_i(i,1)=n_i(i,1)/d;
    n_i(i,2)=n_i(i,2)/d;
end

for i=1:m
     v_i(i,1)=-n_i(i,2);
     v_i(i,2)=n_i(i,1);
end


end

