function y = func_Z(C,i,j)
%FUNC2 辅助计算正则项3——计算C(i,j)在自身处产生的梯度
%   此处显示详细说明
% y=32*C(i,j)-8*(C(i-1,j)+C(i+1,j)+C(i,j-1)+C(i,j+1));



end

