function y = func_N(C,i,j,N,M)
%FUNC2 辅助计算正则项3——计算上方在C(i,j)的产生的梯度
%   此处显示详细说明


    if j+1>M%上一行不存在
        y=0;
    else
        y=2*(C(i,j)-C(i,j+1));
    
   
    end

end

