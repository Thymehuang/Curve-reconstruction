function dB = diff_C_Bspline(t0,u1,t2,u3,t4,t)
%DIFF_C_BSPLINE 计算三次B样条基函数的导数
%   此处显示详细说明
if t0==u1 && u1==t2 && t2==u3 && u3==t4
    error('The input is Wrong! Please check!')
elseif t0==u1 && u1==t2 && t2==u3 && u3~=t4
    dB=-3/(t4-u1).*Q_Bspline(u1,t2,u3,t4,t);
elseif t0~=u1 && u1==t2 && t2==u3 && u3==t4
    dB=3/(u3-t0).*Q_Bspline(t0,u1,t2,u3,t);
else
    dB=3/(u3-t0).*Q_Bspline(t0,u1,t2,u3,t)-3/(t4-u1).*Q_Bspline(u1,t2,u3,t4,t);
end
end



